package com.soulland;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.LightningBoltEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.particles.IParticleData;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.server.ServerWorld;

public class Skills {

    static List<LivingEntity> near(ServerPlayerEntity p, double r) {
        List<LivingEntity> l = new ArrayList<>();
        for (LivingEntity e : p.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r))) {
            if (e != p && e.isAlive()) l.add(e);
        }
        return l;
    }

    static void fx(ServerWorld w, Entity e, IParticleData t, int n) {
        w.sendParticles(t, e.getX(), e.getY() + 1, e.getZ(), n, 1.5, 0.8, 1.5, 0.05);
    }

    static void hit(ServerPlayerEntity p, LivingEntity e, float dmg, double push) {
        e.hurt(DamageSource.playerAttack(p), dmg);
        if (push > 0) {
            Vector3d d = e.position().subtract(p.position()).normalize().scale(push);
            e.push(d.x, 0.5, d.z);
            e.hurtMarked = true;
        }
    }

    static void aoe(ServerPlayerEntity p, ServerWorld w, double r, float dmg, double push, IParticleData part, int n) {
        for (LivingEntity e : near(p, r)) hit(p, e, dmg, push);
        fx(w, p, part, n);
    }

    static void debuff(ServerPlayerEntity p, ServerWorld w, double r, float dmg, double push, Effect eff, int dur, int amp, IParticleData part, int n) {
        for (LivingEntity e : near(p, r)) {
            hit(p, e, dmg, push);
            e.addEffect(new EffectInstance(eff, dur, amp));
        }
        fx(w, p, part, n);
    }

    static void buff(ServerPlayerEntity p, Effect eff, int dur, int amp) {
        p.addEffect(new EffectInstance(eff, dur, amp));
    }

    static void dash(ServerPlayerEntity p, double power) {
        Vector3d l = p.getLookAngle();
        p.setDeltaMovement(l.x * power, 0.2, l.z * power);
        p.hurtMarked = true;
    }

    static void teleport(ServerPlayerEntity p, ServerWorld w, double dist) {
        Vector3d l = p.getLookAngle();
        double dx = l.x * dist, dz = l.z * dist;
        for (double k = 1.0; k >= 0.2; k -= 0.2) {
            AxisAlignedBB b = p.getBoundingBox().move(dx * k, 0, dz * k);
            if (w.noCollision(p, b)) {
                p.connection.teleport(p.getX() + dx * k, p.getY(), p.getZ() + dz * k, p.yRot, p.xRot);
                break;
            }
        }
        fx(w, p, ParticleTypes.PORTAL, 40);
    }

    static void lightning(ServerPlayerEntity p, ServerWorld w, double r, int max, float dmg) {
        int c = 0;
        for (LivingEntity e : near(p, r)) {
            if (c++ >= max) break;
            LightningBoltEntity b = EntityType.LIGHTNING_BOLT.create(w);
            if (b != null) {
                b.moveTo(e.getX(), e.getY(), e.getZ());
                b.setVisualOnly(true);
                w.addFreshEntity(b);
            }
            e.hurt(DamageSource.playerAttack(p), dmg);
        }
    }

    static void burn(ServerPlayerEntity p, ServerWorld w, double r, float dmg, int secs) {
        for (LivingEntity e : near(p, r)) {
            hit(p, e, dmg, 0.6);
            e.setSecondsOnFire(secs);
        }
        fx(w, p, ParticleTypes.FLAME, 80);
    }

    public static void run(Spirit s, int i, ServerPlayerEntity p, ServerWorld w) {
        switch (s) {
            case BLUE_SILVER:
                switch (i) {
                    case 0: debuff(p, w, 6, 2, 0, Effects.MOVEMENT_SLOWDOWN, 80, 4, ParticleTypes.HAPPY_VILLAGER, 50); break;
                    case 1: p.heal(8); buff(p, Effects.REGENERATION, 100, 1); fx(w, p, ParticleTypes.HEART, 12); break;
                    case 2: aoe(p, w, 5, 6, 1.0, ParticleTypes.CRIT, 40); break;
                    default: debuff(p, w, 8, 8, 0.4, Effects.POISON, 100, 1, ParticleTypes.HAPPY_VILLAGER, 120); break;
                }
                break;
            case HAMMER:
                switch (i) {
                    case 0: aoe(p, w, 5, 8, 1.4, ParticleTypes.EXPLOSION, 6); break;
                    case 1: buff(p, Effects.DAMAGE_BOOST, 300, 1); fx(w, p, ParticleTypes.FLAME, 40); break;
                    case 2: lightning(p, w, 10, 5, 10); break;
                    default: buff(p, Effects.DAMAGE_RESISTANCE, 200, 2); buff(p, Effects.ABSORPTION, 200, 2); fx(w, p, ParticleTypes.END_ROD, 40); break;
                }
                break;
            case RABBIT:
                switch (i) {
                    case 0: dash(p, 1.8); fx(w, p, ParticleTypes.CLOUD, 20); break;
                    case 1: buff(p, Effects.INVISIBILITY, 160, 0); buff(p, Effects.MOVEMENT_SPEED, 160, 2); fx(w, p, ParticleTypes.POOF, 20); break;
                    case 2: buff(p, Effects.JUMP, 200, 4); buff(p, Effects.SLOW_FALLING, 200, 0); fx(w, p, ParticleTypes.CLOUD, 20); break;
                    default: aoe(p, w, 7, 9, 1.2, ParticleTypes.SWEEP_ATTACK, 10); break;
                }
                break;
            case TIGER:
                switch (i) {
                    case 0: aoe(p, w, 4, 7, 0.8, ParticleTypes.SWEEP_ATTACK, 8); break;
                    case 1: debuff(p, w, 8, 2, 0.5, Effects.WEAKNESS, 160, 1, ParticleTypes.CLOUD, 40); break;
                    case 2: dash(p, 2.2); aoe(p, w, 3, 6, 0.8, ParticleTypes.CRIT, 20); break;
                    default: buff(p, Effects.DAMAGE_BOOST, 240, 1); buff(p, Effects.MOVEMENT_SPEED, 240, 1); fx(w, p, ParticleTypes.CRIT, 40); break;
                }
                break;
            case ZOMBIE:
                switch (i) {
                    case 0: aoe(p, w, 4, 7, 1.0, ParticleTypes.CRIT, 30); break;
                    case 1: p.heal(6); buff(p, Effects.REGENERATION, 160, 1); fx(w, p, ParticleTypes.HEART, 10); break;
                    case 2: debuff(p, w, 6, 2, 0, Effects.HUNGER, 200, 2, ParticleTypes.SMOKE, 40); break;
                    default: buff(p, Effects.DAMAGE_RESISTANCE, 200, 1); fx(w, p, ParticleTypes.HAPPY_VILLAGER, 20); break;
                }
                break;
            case SKELETON:
                switch (i) {
                    case 0: aoe(p, w, 7, 6, 0.6, ParticleTypes.CRIT, 40); break;
                    case 1: buff(p, Effects.MOVEMENT_SPEED, 200, 2); fx(w, p, ParticleTypes.CLOUD, 15); break;
                    case 2: debuff(p, w, 7, 2, 0, Effects.MOVEMENT_SLOWDOWN, 100, 3, ParticleTypes.POOF, 40); break;
                    default: buff(p, Effects.DAMAGE_RESISTANCE, 200, 1); buff(p, Effects.ABSORPTION, 200, 1); break;
                }
                break;
            case CREEPER:
                switch (i) {
                    case 0: aoe(p, w, 5, 9, 1.6, ParticleTypes.EXPLOSION, 8); break;
                    case 1: buff(p, Effects.DAMAGE_RESISTANCE, 240, 1); fx(w, p, ParticleTypes.HAPPY_VILLAGER, 20); break;
                    case 2: aoe(p, w, 9, 6, 2.0, ParticleTypes.EXPLOSION, 12); break;
                    default: p.setDeltaMovement(p.getDeltaMovement().x, 1.2, p.getDeltaMovement().z); p.hurtMarked = true; buff(p, Effects.SLOW_FALLING, 160, 0); break;
                }
                break;
            case SPIDER:
                switch (i) {
                    case 0: debuff(p, w, 7, 1, 0, Effects.MOVEMENT_SLOWDOWN, 120, 5, ParticleTypes.POOF, 40); break;
                    case 1: debuff(p, w, 6, 3, 0, Effects.POISON, 120, 1, ParticleTypes.HAPPY_VILLAGER, 40); break;
                    case 2: buff(p, Effects.JUMP, 200, 3); buff(p, Effects.SLOW_FALLING, 200, 0); break;
                    default: buff(p, Effects.MOVEMENT_SPEED, 200, 2); buff(p, Effects.DAMAGE_BOOST, 200, 0); break;
                }
                break;
            case ENDERMAN:
                switch (i) {
                    case 0: teleport(p, w, 8); break;
                    case 1: buff(p, Effects.INVISIBILITY, 200, 0); fx(w, p, ParticleTypes.PORTAL, 30); break;
                    case 2: debuff(p, w, 6, 7, 0.8, Effects.WEAKNESS, 120, 1, ParticleTypes.PORTAL, 60); break;
                    default: buff(p, Effects.MOVEMENT_SPEED, 160, 2); buff(p, Effects.INVISIBILITY, 160, 0); teleport(p, w, 5); break;
                }
                break;
            case BLAZE:
                switch (i) {
                    case 0: burn(p, w, 5, 4, 5); break;
                    case 1: buff(p, Effects.FIRE_RESISTANCE, 400, 0); fx(w, p, ParticleTypes.FLAME, 20); break;
                    case 2: burn(p, w, 9, 8, 8); break;
                    default: buff(p, Effects.MOVEMENT_SPEED, 200, 1); buff(p, Effects.FIRE_RESISTANCE, 200, 0); fx(w, p, ParticleTypes.FLAME, 40); break;
                }
                break;
            case IRON_GOLEM:
                switch (i) {
                    case 0: aoe(p, w, 5, 10, 1.8, ParticleTypes.EXPLOSION, 6); break;
                    case 1: buff(p, Effects.DAMAGE_RESISTANCE, 240, 2); fx(w, p, ParticleTypes.CRIT, 20); break;
                    case 2: buff(p, Effects.ABSORPTION, 300, 3); break;
                    default: buff(p, Effects.DAMAGE_BOOST, 300, 2); fx(w, p, ParticleTypes.CRIT, 30); break;
                }
                break;
            case AXE: buff(p, Effects.DAMAGE_BOOST, 160, 0); fx(w, p, ParticleTypes.CRIT, 15); break;
            case PICKAXE: buff(p, Effects.DIG_SPEED, 240, 1); fx(w, p, ParticleTypes.CRIT, 15); break;
            case SHOVEL: buff(p, Effects.MOVEMENT_SPEED, 160, 0); fx(w, p, ParticleTypes.CLOUD, 15); break;
            case HOE: buff(p, Effects.REGENERATION, 120, 0); fx(w, p, ParticleTypes.HAPPY_VILLAGER, 15); break;
            default: break;
        }
    }
}
