package com.soulland.client;

import java.util.HashMap;
import java.util.Map;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.soulland.SoulData;
import com.soulland.SoulLand;
import com.soulland.Spirit;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.model.ItemCameraTransforms;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.RabbitEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.vector.Vector3f;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** โมเดลวิญญาณยุทธ์ยืน/ลอยอยู่ด้านหลังผู้เล่น (ใช้โมเดลมอนสเตอร์/ไอเทมของเกมจริง) */
@Mod.EventBusSubscriber(modid = SoulLand.MODID, value = Dist.CLIENT)
public class SpiritRender {
    private static final Map<Spirit, Entity> DUMMIES = new HashMap<>();
    private static final Map<Spirit, ItemStack> ITEMS = new HashMap<>();

    @SubscribeEvent
    public static void post(RenderPlayerEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        PlayerEntity p = e.getPlayer();
        if (p != mc.player || mc.level == null) return;
        Spirit s = Spirit.byId(SoulData.spirit(p));
        if (s == null || s.render == null || !SoulData.active(p)) return;
        try {
            float pt = e.getPartialRenderTick();
            MatrixStack ms = e.getMatrixStack();
            float yawDeg = p.yBodyRotO + (p.yBodyRot - p.yBodyRotO) * pt;
            double yaw = Math.toRadians(yawDeg);
            double dx = Math.sin(yaw) * s.dist, dz = -Math.cos(yaw) * s.dist;
            if (s.render.startsWith("mob:")) renderMob(mc, p, s, e, ms, pt, yawDeg, dx, dz);
            else renderItem(mc, p, s, e, ms, pt, dx, dz);
        } catch (RuntimeException ex) {
            // ข้ามถ้าเรนเดอร์พลาด
        }
    }

    private static void renderMob(Minecraft mc, PlayerEntity p, Spirit s, RenderPlayerEvent.Post e, MatrixStack ms, float pt, float yawDeg, double dx, double dz) {
        Entity d = DUMMIES.get(s);
        if (d == null || d.level != mc.level) {
            EntityType<?> t = ForgeRegistries.ENTITIES.getValue(new ResourceLocation(s.render.substring(4)));
            if (t == null) return;
            d = t.create(mc.level);
            if (d == null) return;
            if (d instanceof RabbitEntity) ((RabbitEntity) d).setRabbitType(1);
            DUMMIES.put(s, d);
        }
        d.moveTo(p.getX(), p.getY(), p.getZ(), yawDeg, 0F);
        d.tickCount = p.tickCount;
        if (d instanceof LivingEntity) {
            LivingEntity l = (LivingEntity) d;
            l.yBodyRot = l.yBodyRotO = yawDeg;
            l.yHeadRot = p.yHeadRotO + (p.yHeadRot - p.yHeadRotO) * pt;
            l.yHeadRotO = l.yHeadRot;
            l.animationPosition = p.animationPosition;
            l.animationSpeed = p.animationSpeed;
            l.animationSpeedOld = p.animationSpeedOld;
            l.hurtTime = 0;
            l.deathTime = 0;
        }
        ms.pushPose();
        ms.translate(dx, 0, dz);
        ms.scale((float) s.scale, (float) s.scale, (float) s.scale);
        mc.getEntityRenderDispatcher().render(d, 0, 0, 0, yawDeg, pt, ms, e.getBuffers(), e.getLight());
        ms.popPose();
    }

    private static void renderItem(Minecraft mc, PlayerEntity p, Spirit s, RenderPlayerEvent.Post e, MatrixStack ms, float pt, double dx, double dz) {
        ItemStack st = ITEMS.get(s);
        if (st == null) {
            Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(s.render.substring(5)));
            if (it == null) return;
            st = new ItemStack(it);
            ITEMS.put(s, st);
        }
        float t = p.tickCount + pt;
        ms.pushPose();
        ms.translate(dx, 1.4 + 0.06 * Math.sin(t * 0.07), dz);
        ms.mulPose(Vector3f.YP.rotationDegrees(t * 2F));
        ms.scale((float) s.scale, (float) s.scale, (float) s.scale);
        mc.getItemRenderer().renderStatic(st, ItemCameraTransforms.TransformType.FIXED, e.getLight(), OverlayTexture.NO_OVERLAY, ms, e.getBuffers());
        ms.popPose();
    }
}
