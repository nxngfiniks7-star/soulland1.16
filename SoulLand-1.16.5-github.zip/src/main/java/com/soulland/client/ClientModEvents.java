package com.soulland.client;

import com.soulland.SoulLand;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = SoulLand.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void setup(FMLClientSetupEvent e) {
        ClientRegistry.registerKeyBinding(Keys.TOGGLE);
        ClientRegistry.registerKeyBinding(Keys.RINGS);
        ClientRegistry.registerKeyBinding(Keys.MEDITATE);
        ClientRegistry.registerKeyBinding(Keys.AWAKEN);
        ClientRegistry.registerKeyBinding(Keys.REROLL);
        ClientRegistry.registerKeyBinding(Keys.NEXT);
        ClientRegistry.registerKeyBinding(Keys.CAST);
    }
}
