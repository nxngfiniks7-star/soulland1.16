package com.soulland.client;

import java.util.ArrayList;
import java.util.List;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;
import com.soulland.SoulData;
import com.soulland.SoulLand;
import com.soulland.SoulLogic;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** วงแหวนวิญญาณ + อนิเมชั่น (ปลูกวิญญาณ / ดูดซับวงแหวน / เปิดวิญญาณ / นั่งฝึก) วาดเป็นแสงรอบตัวผู้เล่น */
@Mod.EventBusSubscriber(modid = SoulLand.MODID, value = Dist.CLIENT)
public class FxRender {
    private static class Fx { int ent, type, dur, param, start; }

    private static final List<Fx> LIST = new ArrayList<>();
    private static int clock = 0;
    private static final int SEG = 36;
    private static final float[] GOLD = {1.0f, 0.82f, 0.2f};

    public static void add(int ent, int type, int dur, int param) {
        Fx f = new Fx();
        f.ent = ent; f.type = type; f.dur = dur; f.param = param; f.start = clock;
        LIST.add(f);
    }

    public static void tick() {
        clock++;
        LIST.removeIf(f -> clock - f.start > f.dur + 12);
    }

    // ---------- ตัวช่วยวาด ----------
    private static void v(Matrix4f m, IVertexBuilder vb, float x, float y, float z, float[] c, float a) {
        vb.vertex(m, x, y, z).color(c[0], c[1], c[2], a).endVertex();
    }

    /** แถบวงแหวนแนวนอน (a0..a1 เป็นมุมเรเดียน) */
    private static void band(Matrix4f m, IVertexBuilder vb, float y, float r1, float r2, double a0, double a1, float[] c, float alpha) {
        int n = Math.max(1, (int) Math.ceil(SEG * Math.abs(a1 - a0) / (Math.PI * 2)));
        for (int i = 0; i < n; i++) {
            double s = a0 + (a1 - a0) * i / n, e = a0 + (a1 - a0) * (i + 1) / n;
            float c0 = (float) Math.cos(s), s0 = (float) Math.sin(s), c1 = (float) Math.cos(e), s1 = (float) Math.sin(e);
            v(m, vb, r1 * c0, y, r1 * s0, c, alpha);
            v(m, vb, r2 * c0, y, r2 * s0, c, alpha);
            v(m, vb, r2 * c1, y, r2 * s1, c, alpha);
            v(m, vb, r1 * c1, y, r1 * s1, c, alpha);
        }
    }

    private static void disc(Matrix4f m, IVertexBuilder vb, float y, float r1, float r2, float[] c, float alpha) {
        band(m, vb, y, r1, r2, 0, Math.PI * 2, c, alpha);
    }

    /** ผนังทรงกระบอกแสง (โปร่งใสค่อยๆ จางขึ้นด้านบน) */
    private static void wall(Matrix4f m, IVertexBuilder vb, float r, float y0, float y1, float[] c, float aBottom, float aTop) {
        for (int i = 0; i < SEG; i++) {
            double s = Math.PI * 2 * i / SEG, e = Math.PI * 2 * (i + 1) / SEG;
            float x0 = r * (float) Math.cos(s), z0 = r * (float) Math.sin(s), x1 = r * (float) Math.cos(e), z1 = r * (float) Math.sin(e);
            v(m, vb, x0, y0, z0, c, aBottom);
            v(m, vb, x0, y1, z0, c, aTop);
            v(m, vb, x1, y1, z1, c, aTop);
            v(m, vb, x1, y0, z1, c, aBottom);
        }
    }

    /** วงแหวนหนึ่งวง: ฐานเรืองแสง + ขอบ + เส้นโค้งสว่างหมุนวน */
    private static void ringShape(Matrix4f m, IVertexBuilder vb, float y, float rad, float[] c, float t, float spin, float strength) {
        disc(m, vb, y, rad - 0.07f, rad + 0.07f, c, 0.45f * strength);
        disc(m, vb, y, rad + 0.07f, rad + 0.1f, c, 0.8f * strength);
        disc(m, vb, y, rad - 0.1f, rad - 0.07f, c, 0.8f * strength);
        float[] bright = {Math.min(1f, c[0] + 0.5f), Math.min(1f, c[1] + 0.5f), Math.min(1f, c[2] + 0.5f)};
        for (int k = 0; k < 3; k++) {
            double a = t * spin + k * Math.PI * 2 / 3;
            band(m, vb, y + 0.005f, rad - 0.05f, rad + 0.05f, a, a + 0.7, bright, 0.9f * strength);
        }
    }

    private static float[] ringColor(int type) {
        return SoulLogic.RC[Math.max(0, Math.min(4, type))];
    }

    private static float[] rgb(int color) {
        return new float[]{((color >> 16) & 255) / 255f, ((color >> 8) & 255) / 255f, (color & 255) / 255f};
    }

    // ---------- เรนเดอร์ ----------
    @SubscribeEvent
    public static void post(RenderPlayerEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        PlayerEntity p = e.getPlayer();
        if (mc.level == null) return;
        try {
            MatrixStack ms = e.getMatrixStack();
            IVertexBuilder vb = e.getBuffers().getBuffer(RenderType.lightning());
            float t = clock + e.getPartialRenderTick();
            ms.pushPose();
            Matrix4f m = ms.last().pose();
            if (p == mc.player && SoulData.spirit(p) >= 0) {
                if (SoulData.ringsOn(p)) rings(m, vb, p, t);
                if (SoulData.med(p)) aura(m, vb, t);
            }
            for (Fx f : LIST) if (f.ent == p.getId()) fx(m, vb, f, t);
            ms.popPose();
        } catch (RuntimeException ex) {
            // ข้ามถ้าเรนเดอร์พลาด
        }
    }

    private static float slotY(int i) { return 0.1f + i * 0.2f; }
    private static float slotRad(int type) { return 0.62f + 0.04f * type; }

    private static void rings(Matrix4f m, IVertexBuilder vb, PlayerEntity p, float t) {
        int[] r = SoulData.rings(p);
        for (int i = 0; i < r.length; i++) {
            float rad = slotRad(r[i]) + 0.03f * (float) Math.sin(t * 0.1 + i);
            float s = 0.85f + 0.15f * (float) Math.sin(t * 0.15 + i * 0.7);
            ringShape(m, vb, slotY(i), rad, ringColor(r[i]), t, (i % 2 == 0 ? 0.08f : -0.08f), s);
        }
    }

    /** แสงสีทองรอบตัวตอนนั่งฝึก */
    private static void aura(Matrix4f m, IVertexBuilder vb, float t) {
        float pulse = 0.18f + 0.06f * (float) Math.sin(t * 0.15);
        wall(m, vb, 0.85f, 0f, 2.1f, GOLD, pulse + 0.15f, 0.02f);
        wall(m, vb, 0.6f, 0f, 1.9f, GOLD, pulse + 0.1f, 0.0f);
        for (int k = 0; k < 3; k++) {
            float f = (t * 0.02f + k / 3f) % 1f;
            disc(m, vb, f * 2.0f, 0.88f - f * 0.1f, 0.96f - f * 0.1f, GOLD, 0.6f * (1 - f));
        }
        float g = 1.1f + 0.1f * (float) Math.sin(t * 0.1);
        ringShape(m, vb, 0.03f, g, GOLD, t, 0.06f, 0.9f);
        disc(m, vb, 0.03f, 0f, 0.5f, GOLD, 0.15f);
    }

    private static void fx(Matrix4f m, IVertexBuilder vb, Fx f, float t) {
        float age = t - f.start;
        float prog = Math.max(0f, Math.min(1f, age / f.dur));
        if (f.type == 0) { // ปลูก/รีวิญญาณยุทธ์
            float[] c = rgb(f.param);
            float glow = (float) Math.sin(prog * Math.PI);
            wall(m, vb, 0.9f, 0f, 3.2f, c, 0.2f + 0.4f * glow, 0.0f);
            wall(m, vb, 0.5f, 0f, 3.2f, new float[]{1, 1, 1}, 0.1f + 0.3f * glow, 0.0f);
            for (int k = 0; k < 3; k++) {
                float pk = (prog * 1.5f + k / 3f) % 1f;
                float rad = 1.6f * (1 - pk * 0.75f);
                disc(m, vb, pk * 2.2f, rad - 0.05f, rad + 0.05f, c, 0.7f * (1 - pk));
            }
            disc(m, vb, 0.03f, 0f, 1.2f * glow + 0.1f, c, 0.25f);
            ringShape(m, vb, 0.04f, 1.3f * glow + 0.1f, c, age, 0.2f, 1f);
            if (prog > 0.85f) {
                float q = (prog - 0.85f) / 0.15f;
                disc(m, vb, 0.05f, 3f * q, 3f * q + 0.15f, c, 0.8f * (1 - q));
            }
        } else if (f.type == 1) { // ดูดซับวงแหวน
            int type = f.param >> 4, slot = f.param & 15;
            float[] c = ringColor(type);
            float[] cc = {Math.max(c[0], 0.25f), Math.max(c[1], 0.15f), Math.max(c[2], 0.3f)};
            float q = prog * prog * (3 - 2 * prog);
            float y = 2.9f + (slotY(slot) - 2.9f) * q;
            float rad = 2.0f + (slotRad(type) - 2.0f) * q;
            wall(m, vb, 0.55f, 0f, 2.6f, cc, 0.1f + 0.25f * prog, 0.0f);
            ringShape(m, vb, y, rad, cc, age, 0.3f, 1f);
            if (prog < 0.95f) disc(m, vb, 0.03f, 0f, 0.9f * (0.5f + 0.5f * prog), cc, 0.2f);
            if (prog > 0.9f) {
                float k = (prog - 0.9f) / 0.1f;
                disc(m, vb, slotY(slot), slotRad(type) + 0.8f * k, slotRad(type) + 0.8f * k + 0.1f, cc, 0.9f * (1 - k));
            }
        } else if (f.type == 2) { // เปิดวิญญาณยุทธ์
            float[] c = rgb(f.param);
            float q = (float) Math.sin(prog * Math.PI / 2);
            float R = 1.7f * q;
            float fade = 1f - prog * 0.7f;
            ringShape(m, vb, 0.03f, Math.max(0.1f, R), c, age, 0.15f, fade);
            ringShape(m, vb, 0.04f, Math.max(0.05f, R * 0.6f), c, age, -0.2f, fade);
            disc(m, vb, 0.02f, 0f, R, c, 0.18f * fade);
            wall(m, vb, 0.8f, 0f, 2.6f * q, c, 0.35f * (1 - prog), 0f);
        }
    }
}
