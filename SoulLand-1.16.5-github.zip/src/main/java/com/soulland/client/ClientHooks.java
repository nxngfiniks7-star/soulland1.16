package com.soulland.client;

import com.soulland.SoulData;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundNBT;

public class ClientHooks {
    public static void sync(CompoundNBT t) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && t != null) mc.player.getPersistentData().put(SoulData.KEY, t);
    }

    public static void fx(int ent, int type, int dur, int param) {
        FxRender.add(ent, type, dur, param);
    }
}
