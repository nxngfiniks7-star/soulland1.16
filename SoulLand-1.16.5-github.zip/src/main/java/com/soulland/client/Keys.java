package com.soulland.client;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.settings.KeyBinding;

public class Keys {
    private static KeyBinding k(String n, int c) { return new KeyBinding("key.soulland." + n, c, "key.categories.soulland"); }

    public static final KeyBinding TOGGLE = k("toggle", GLFW.GLFW_KEY_G);
    public static final KeyBinding RINGS = k("rings", GLFW.GLFW_KEY_H);
    public static final KeyBinding MEDITATE = k("meditate", GLFW.GLFW_KEY_K);
    public static final KeyBinding AWAKEN = k("awaken", GLFW.GLFW_KEY_M);
    public static final KeyBinding REROLL = k("reroll", GLFW.GLFW_KEY_N);
    public static final KeyBinding NEXT = k("next", GLFW.GLFW_KEY_V);
    public static final KeyBinding CAST = k("cast", GLFW.GLFW_KEY_R);
}
