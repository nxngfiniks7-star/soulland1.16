package com.soulland;

import java.util.Arrays;
import java.util.UUID;

import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.ai.attributes.ModifiableAttributeInstance;
import net.minecraft.entity.item.ArmorStandEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.server.ServerWorld;

public class SoulLogic {
    public static final float[][] RC = {{1, 1, 1}, {1, 0.84f, 0}, {0.6f, 0.2f, 1}, {0.3f, 0.1f, 0.4f}, {1, 0.1f, 0.1f}};
    private static final UUID HP_ID = UUID.fromString("5a7c1e22-6d0b-4b0e-9c55-1f2d0a7e8b10");

    public static int need(int level) { return 20 + level * 15; }

    /** เลเวลสูงสุดที่ไปได้ตามจำนวนวงแหวน (คอขวด) */
    public static int levelCap(int rings) { return rings >= 9 ? 100 : 10 * (rings + 1); }

    private static void msg(ServerPlayerEntity p, String s, boolean bar) {
        p.displayClientMessage(new StringTextComponent(s), bar);
    }

    /** เลือดสูงสุดเพิ่มตามเลเวล (+2 ต่อเลเวล) */
    public static void applyHp(ServerPlayerEntity p, boolean full) {
        ModifiableAttributeInstance a = p.getAttribute(Attributes.MAX_HEALTH);
        if (a == null) return;
        a.removeModifier(HP_ID);
        if (SoulData.spirit(p) >= 0) {
            a.addPermanentModifier(new AttributeModifier(HP_ID, "soulland_hp", SoulData.level(p) * 2.0, AttributeModifier.Operation.ADDITION));
        }
        if (full) p.setHealth(p.getMaxHealth());
        else if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }

    public static void addXp(ServerPlayerEntity p, int amt) {
        if (SoulData.spirit(p) < 0) return;
        int lv = SoulData.level(p);
        int rings = SoulData.rings(p).length;
        int cap = levelCap(rings);
        int xp = SoulData.xp(p) + amt;
        boolean up = false;
        while (lv < cap && lv < 100 && xp >= need(lv)) {
            xp -= need(lv);
            lv++;
            up = true;
            msg(p, "เลเวลอัป! ตอนนี้เลเวล " + lv, false);
        }
        if (lv >= cap && rings < 9) xp = Math.min(xp, need(lv) - 1);
        SoulData.setLevel(p, lv);
        SoulData.setXp(p, xp);
        if (up) applyHp(p, false);
        Net.sync(p);
    }

    private static boolean busy(ServerPlayerEntity p) {
        return SoulData.med(p) || SoulData.absorbing(p) || SoulData.awakening(p);
    }

    private static void sit(ServerPlayerEntity p) {
        CompoundNBT t = SoulData.tag(p);
        t.putDouble("mdX", p.getX());
        t.putDouble("mdY", p.getY());
        t.putDouble("mdZ", p.getZ());
        ArmorStandEntity seat = new ArmorStandEntity(p.level, p.getX(), p.getY() - 1.55, p.getZ());
        seat.setInvisible(true);
        seat.setNoGravity(true);
        seat.setInvulnerable(true);
        seat.addTag("sl_seat");
        p.level.addFreshEntity(seat);
        p.startRiding(seat, true);
    }

    private static void unsit(ServerPlayerEntity p) {
        CompoundNBT t = SoulData.tag(p);
        Entity v = p.getVehicle();
        p.stopRiding();
        if (v != null && v.getTags().contains("sl_seat")) v.remove();
        p.connection.teleport(t.getDouble("mdX"), t.getDouble("mdY"), t.getDouble("mdZ"), p.yRot, p.xRot);
    }

    /** คลิกขวาวงแหวน: นั่งดูดซับ 4 วินาที พร้อมอนิเมชั่น */
    public static boolean startAbsorb(ServerPlayerEntity p, int ringType) {
        if (SoulData.spirit(p) < 0) { msg(p, "ต้องปลูกวิญญาณยุทธ์ก่อน (กด M)", true); return false; }
        if (busy(p)) { msg(p, "กำลังทำอย่างอื่นอยู่", true); return false; }
        int[] r = SoulData.rings(p);
        if (r.length >= 9) { msg(p, "มีวงแหวนครบ 9 วงแล้ว", true); return false; }
        int needLv = 10 * (r.length + 1);
        if (SoulData.level(p) < needLv) { msg(p, "ต้องเลเวล " + needLv + " ถึงจะดูดซับวงแหวนวงที่ " + (r.length + 1), true); return false; }
        if (p.isPassenger()) return false;
        if (!p.isOnGround()) { msg(p, "ต้องยืนบนพื้นถึงจะดูดซับได้", true); return false; }
        CompoundNBT t = SoulData.tag(p);
        sit(p);
        t.putBoolean("abs", true);
        t.putInt("absType", ringType);
        t.putInt("absTick", 0);
        Net.fx(p, 1, ABSORB_TICKS, ringType * 16 + r.length);
        msg(p, "กำลังดูดซับวงแหวนวิญญาณ...", true);
        Net.sync(p);
        return true;
    }

    public static final int ABSORB_TICKS = 80;

    public static void absorbTick(ServerPlayerEntity p) {
        if (!p.isAlive() || !p.isPassenger()) { stopAbsorb(p, false); return; }
        CompoundNBT t = SoulData.tag(p);
        int tick = t.getInt("absTick") + 1;
        t.putInt("absTick", tick);
        float[] c = RC[Math.max(0, Math.min(4, t.getInt("absType")))];
        ServerWorld w = (ServerWorld) p.level;
        if (tick % 4 == 0) {
            w.sendParticles(new RedstoneParticleData(Math.max(c[0], 0.2f), Math.max(c[1], 0.2f), Math.max(c[2], 0.2f), 1.3f),
                    p.getX() + (w.random.nextDouble() - 0.5) * 1.6, p.getY() + 0.2 + w.random.nextDouble() * 1.6,
                    p.getZ() + (w.random.nextDouble() - 0.5) * 1.6, 1, 0, 0.05, 0, 0.0);
        }
        if (tick >= ABSORB_TICKS) stopAbsorb(p, true);
    }

    public static void stopAbsorb(ServerPlayerEntity p, boolean done) {
        CompoundNBT t = SoulData.tag(p);
        if (!t.getBoolean("abs")) return;
        t.putBoolean("abs", false);
        unsit(p);
        int type = t.getInt("absType");
        if (done) {
            int[] r = SoulData.rings(p);
            int[] n = Arrays.copyOf(r, r.length + 1);
            n[r.length] = type;
            SoulData.setRings(p, n);
            SoulData.setRingsOn(p, true);
            msg(p, "ดูดซับวงแหวนวงที่ " + n.length + " สำเร็จ!", false);
        } else {
            ItemStack st = new ItemStack(ModItems.RINGS.get(Math.max(0, Math.min(4, type))).get());
            if (!p.inventory.add(st)) p.drop(st, false);
            msg(p, "ยกเลิกการดูดซับ (คืนวงแหวนให้แล้ว)", true);
        }
        Net.sync(p);
    }

    private static void removeHammers(ServerPlayerEntity p) {
        for (int i = 0; i < p.inventory.getContainerSize(); i++) {
            if (p.inventory.getItem(i).getItem() == ModItems.HAMMER.get()) p.inventory.setItem(i, ItemStack.EMPTY);
        }
    }

    private static void giveHammer(ServerPlayerEntity p) {
        ItemStack st = new ItemStack(ModItems.HAMMER.get());
        st.getOrCreateTag().putBoolean("Unbreakable", true);
        if (!p.addItem(st)) p.drop(st, false);
    }

    /** G: เปิด/ปิดวิญญาณยุทธ์ */
    public static void toggle(ServerPlayerEntity p) {
        Spirit s = Spirit.byId(SoulData.spirit(p));
        if (s == null) { msg(p, "ยังไม่มีวิญญาณยุทธ์ (กด M เพื่อปลูก)", true); return; }
        boolean on = !SoulData.active(p);
        SoulData.setActive(p, on);
        if (s.weapon) {
            if (on) giveHammer(p); else removeHammers(p);
        }
        msg(p, s.thName + (on ? " : เปิด" : " : ปิด"), true);
        if (on) Net.fx(p, 2, 30, s.color);
        Net.sync(p);
    }

    /** H: เปิด/ปิดวงแหวน */
    public static void toggleRings(ServerPlayerEntity p) {
        if (SoulData.spirit(p) < 0) { msg(p, "ยังไม่มีวิญญาณยุทธ์ (กด M เพื่อปลูก)", true); return; }
        boolean on = !SoulData.ringsOn(p);
        SoulData.setRingsOn(p, on);
        if (on && SoulData.rings(p).length == 0) msg(p, "วงแหวนวิญญาณ : เปิด (แต่ยังไม่มีวงแหวน ต้องดูดซับก่อน)", true);
        else msg(p, "วงแหวนวิญญาณ : " + (on ? "เปิด" : "ปิด"), true);
        Net.sync(p);
    }

    public static int unlocked(ServerPlayerEntity p) {
        Spirit s = Spirit.byId(SoulData.spirit(p));
        if (s == null) return 0;
        if (s.skills.length == 1) return 1;
        return Math.min(SoulData.rings(p).length, s.skills.length);
    }

    /** V: เปลี่ยนสกิล */
    public static void nextSkill(ServerPlayerEntity p) {
        int u = unlocked(p);
        if (u <= 0) { msg(p, "ยังไม่มีทักษะ (ต้องดูดซับวงแหวน)", true); return; }
        SoulData.setSel(p, (SoulData.sel(p) + 1) % u);
        Net.sync(p);
    }

    /** R: ใช้สกิล */
    public static void cast(ServerPlayerEntity p) {
        Spirit s = Spirit.byId(SoulData.spirit(p));
        if (s == null) { msg(p, "ยังไม่มีวิญญาณยุทธ์ (กด M เพื่อปลูก)", true); return; }
        if (!SoulData.active(p)) { msg(p, "เปิดวิญญาณยุทธ์ก่อน (กด G)", true); return; }
        int sel = SoulData.sel(p);
        if (sel >= unlocked(p)) { msg(p, "ยังไม่ปลดล็อกทักษะนี้", true); return; }
        long now = p.level.getGameTime();
        if (now < SoulData.cd(p)) return;
        float cost = 8 + sel * 6;
        if (SoulData.mana(p) < cost) { msg(p, "มานาไม่พอ", true); return; }
        SoulData.setMana(p, SoulData.mana(p) - cost);
        SoulData.setCd(p, now + 30);
        Skills.run(s, sel, p, (ServerWorld) p.level);
        Net.sync(p);
    }

    /** M: ปลูกวิญญาณยุทธ์ (สุ่มวิญญาณ + เลเวล 1-10) / N: รี  มีอนิเมชั่น 3 วินาทีก่อนได้ผล */
    public static void awaken(ServerPlayerEntity p, boolean reroll) {
        int cur = SoulData.spirit(p);
        if (!reroll && cur >= 0) { msg(p, "ปลูกวิญญาณยุทธ์แล้ว (กด N เพื่อรี)", true); return; }
        if (reroll && cur < 0) { msg(p, "ยังไม่มีวิญญาณยุทธ์ (กด M เพื่อปลูก)", true); return; }
        if (SoulData.absorbing(p) || SoulData.awakening(p)) return;
        stopMeditate(p, false);
        Spirit s = Spirit.roll(p.getRandom(), reroll ? Spirit.byId(cur) : null);
        CompoundNBT t = SoulData.tag(p);
        t.putBoolean("aw", true);
        t.putInt("awTick", 0);
        t.putInt("awSp", s.ordinal());
        t.putInt("awLv", 1 + p.getRandom().nextInt(10));
        t.putBoolean("awRe", reroll);
        Net.fx(p, 0, AWAKEN_TICKS, s.color);
        msg(p, reroll ? "กำลังรีวิญญาณยุทธ์..." : "กำลังปลูกวิญญาณยุทธ์...", true);
        Net.sync(p);
    }

    public static final int AWAKEN_TICKS = 60;

    public static void awakenTick(ServerPlayerEntity p) {
        CompoundNBT t = SoulData.tag(p);
        int tick = t.getInt("awTick") + 1;
        t.putInt("awTick", tick);
        p.addEffect(new EffectInstance(Effects.MOVEMENT_SLOWDOWN, 5, 6, false, false));
        ServerWorld w = (ServerWorld) p.level;
        double pr = tick / (double) AWAKEN_TICKS, r = 1.8 * (1 - pr * 0.8);
        for (int i = 0; i < 2; i++) {
            double ang = tick * 0.3 + i * 3.14159;
            w.sendParticles(ParticleTypes.END_ROD, p.getX() + Math.cos(ang) * r, p.getY() + 0.2 + pr * 2.0, p.getZ() + Math.sin(ang) * r, 1, 0, 0, 0, 0.0);
        }
        if (tick >= AWAKEN_TICKS) finishAwaken(p);
    }

    private static void finishAwaken(ServerPlayerEntity p) {
        CompoundNBT t = SoulData.tag(p);
        t.putBoolean("aw", false);
        boolean reroll = t.getBoolean("awRe");
        Spirit s = Spirit.byId(t.getInt("awSp"));
        int lv = Math.max(1, t.getInt("awLv"));
        if (s == null) return;
        removeHammers(p);
        SoulData.setSpirit(p, s.ordinal());
        SoulData.setLevel(p, lv);
        SoulData.setXp(p, 0);
        SoulData.setRings(p, new int[0]);
        SoulData.setSel(p, 0);
        SoulData.setActive(p, true);
        SoulData.setRingsOn(p, false);
        SoulData.setMana(p, SoulData.maxMana(lv));
        applyHp(p, true);
        if (s.weapon) giveHammer(p);
        msg(p, (reroll ? "รีวิญญาณยุทธ์สำเร็จ: " : "ปลูกวิญญาณยุทธ์สำเร็จ: ") + s.thName + "  เลเวลเริ่มต้น " + lv, false);
        ServerWorld w = (ServerWorld) p.level;
        w.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 80, 0.7, 1.0, 0.7, 0.2);
        Net.sync(p);
    }

    /** N: กดครั้งแรกขอรี ต้องกดซ้ำภายใน 4 วินาทีเพื่อยืนยัน */
    public static void requestReroll(ServerPlayerEntity p) {
        if (SoulData.spirit(p) < 0) { msg(p, "ยังไม่มีวิญญาณยุทธ์ (กด M เพื่อปลูก)", true); return; }
        long now = p.level.getGameTime();
        CompoundNBT t = SoulData.tag(p);
        if (now <= t.getLong("rr")) {
            t.putLong("rr", 0);
            awaken(p, true);
        } else {
            t.putLong("rr", now + 80);
            msg(p, "กด N อีกครั้งภายใน 4 วินาทีเพื่อยืนยันรีวิญญาณยุทธ์ (เลเวล เลือด วงแหวนจะถูกรีเซ็ต)", true);
        }
    }

    /** K: นั่งฝึก */
    public static void toggleMeditate(ServerPlayerEntity p) {
        if (SoulData.med(p)) { stopMeditate(p, true); return; }
        if (SoulData.spirit(p) < 0) { msg(p, "ยังไม่มีวิญญาณยุทธ์ (กด M เพื่อปลูก)", true); return; }
        if (busy(p) || p.isPassenger()) return;
        if (!p.isOnGround()) { msg(p, "ต้องยืนบนพื้นถึงจะนั่งฝึกได้", true); return; }
        int rings = SoulData.rings(p).length;
        if (SoulData.level(p) >= levelCap(rings) && rings < 9) { msg(p, "ถึงคอขวดแล้ว ต้องดูดซับวงแหวนก่อน", true); return; }
        sit(p);
        SoulData.setMed(p, true);
        SoulData.tag(p).putInt("medTick", 0);
        msg(p, "เริ่มนั่งฝึก (กด K อีกครั้งเพื่อหยุด)", true);
        Net.sync(p);
    }

    public static void stopMeditate(ServerPlayerEntity p, boolean notify) {
        if (!SoulData.med(p)) return;
        SoulData.setMed(p, false);
        unsit(p);
        if (notify) msg(p, "หยุดนั่งฝึก", true);
        Net.sync(p);
    }

    public static void meditateTick(ServerPlayerEntity p) {
        if (!p.isAlive() || !p.isPassenger()) { stopMeditate(p, false); return; }
        CompoundNBT t = SoulData.tag(p);
        int tick = t.getInt("medTick") + 1;
        t.putInt("medTick", tick);
        ServerWorld w = (ServerWorld) p.level;
        if (tick % 3 == 0) {
            w.sendParticles(new RedstoneParticleData(1.0f, 0.82f, 0.15f, 1.4f), p.getX() + (w.random.nextDouble() - 0.5) * 1.2,
                    p.getY() + 0.1 + w.random.nextDouble() * 1.5, p.getZ() + (w.random.nextDouble() - 0.5) * 1.2, 1, 0, 0.08, 0, 0.0);
        }
        if (tick % 20 == 0) {
            int rings = SoulData.rings(p).length, lv = SoulData.level(p);
            if (lv >= levelCap(rings) && rings < 9) {
                stopMeditate(p, false);
                msg(p, "ถึงคอขวดแล้ว ต้องดูดซับวงแหวนก่อน", true);
                return;
            }
            if (tick % 40 == 0) addXp(p, 3);
            SoulData.setMana(p, Math.min(SoulData.maxMana(lv), SoulData.mana(p) + 6 + lv / 4f));
            p.heal(0.5F);
            Net.sync(p);
        }
    }
}
