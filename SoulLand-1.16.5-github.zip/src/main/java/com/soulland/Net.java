package com.soulland;

import java.util.function.Supplier;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.network.NetworkEvent;
import net.minecraftforge.fml.network.NetworkRegistry;
import net.minecraftforge.fml.network.PacketDistributor;
import net.minecraftforge.fml.network.simple.SimpleChannel;

public class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(SoulLand.MODID, "main"), () -> V, V::equals, V::equals);

    public static void register() {
        CH.registerMessage(0, ActionMsg.class, ActionMsg::enc, ActionMsg::dec, ActionMsg::handle);
        CH.registerMessage(1, SyncMsg.class, SyncMsg::enc, SyncMsg::dec, SyncMsg::handle);
        CH.registerMessage(2, FxMsg.class, FxMsg::enc, FxMsg::dec, FxMsg::handle);
        CH.registerMessage(3, PickupMsg.class, PickupMsg::enc, PickupMsg::dec, PickupMsg::handle);
    }

    public static void sync(ServerPlayerEntity p) {
        CompoundNBT t = SoulData.tag(p).copy();
        CH.send(PacketDistributor.PLAYER.with(() -> p), new SyncMsg(t));
    }

    /** ส่งอนิเมชั่นให้ตัวเองและคนที่อยู่ใกล้ (0=ปลูกวิญญาณ 1=ดูดซับวงแหวน 2=เปิดวิญญาณ) */
    public static void fx(ServerPlayerEntity p, int type, int dur, int param) {
        CH.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), new FxMsg(p.getId(), type, dur, param));
    }

    public static class ActionMsg {
        public final int action;
        public ActionMsg(int a) { action = a; }
        public static void enc(ActionMsg m, PacketBuffer b) { b.writeInt(m.action); }
        public static ActionMsg dec(PacketBuffer b) { return new ActionMsg(b.readInt()); }
        public static void handle(ActionMsg m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> {
                ServerPlayerEntity p = c.getSender();
                if (p == null) return;
                if (m.action == 0) SoulLogic.toggle(p);
                else if (m.action == 1) SoulLogic.cast(p);
                else if (m.action == 2) SoulLogic.nextSkill(p);
                else if (m.action == 3) SoulLogic.toggleRings(p);
                else if (m.action == 4) SoulLogic.toggleMeditate(p);
                else if (m.action == 5) SoulLogic.awaken(p, false);
                else if (m.action == 6) SoulLogic.requestReroll(p);
            });
            c.setPacketHandled(true);
        }
    }

    public static class SyncMsg {
        public final CompoundNBT tag;
        public SyncMsg(CompoundNBT t) { tag = t; }
        public static void enc(SyncMsg m, PacketBuffer b) { b.writeNbt(m.tag); }
        public static SyncMsg dec(PacketBuffer b) { return new SyncMsg(b.readNbt()); }
        public static void handle(SyncMsg m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.soulland.client.ClientHooks.sync(m.tag)));
            c.setPacketHandled(true);
        }
    }

    public static class FxMsg {
        public final int ent, type, dur, param;
        public FxMsg(int ent, int type, int dur, int param) { this.ent = ent; this.type = type; this.dur = dur; this.param = param; }
        public static void enc(FxMsg m, PacketBuffer b) { b.writeInt(m.ent); b.writeInt(m.type); b.writeInt(m.dur); b.writeInt(m.param); }
        public static FxMsg dec(PacketBuffer b) { return new FxMsg(b.readInt(), b.readInt(), b.readInt(), b.readInt()); }
        public static void handle(FxMsg m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.soulland.client.ClientHooks.fx(m.ent, m.type, m.dur, m.param)));
            c.setPacketHandled(true);
        }
    }

    /** คลิกซ้ายเก็บวงแหวนที่ดรอป */
    public static class PickupMsg {
        public final int id;
        public PickupMsg(int id) { this.id = id; }
        public static void enc(PickupMsg m, PacketBuffer b) { b.writeInt(m.id); }
        public static PickupMsg dec(PacketBuffer b) { return new PickupMsg(b.readInt()); }
        public static void handle(PickupMsg m, Supplier<NetworkEvent.Context> s) {
            NetworkEvent.Context c = s.get();
            c.enqueueWork(() -> {
                ServerPlayerEntity p = c.getSender();
                if (p == null) return;
                Entity en = p.level.getEntity(m.id);
                if (!(en instanceof ItemEntity) || en.distanceToSqr(p) > 64) return;
                ItemEntity ie = (ItemEntity) en;
                if (!(ie.getItem().getItem() instanceof ModItems.RingItem)) return;
                ItemStack copy = ie.getItem().copy();
                if (p.inventory.add(copy)) ie.remove();
                else ie.setItem(copy);
                p.level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_PICKUP, SoundCategory.PLAYERS, 0.4F, 1.2F);
            });
            c.setPacketHandled(true);
        }
    }
}
